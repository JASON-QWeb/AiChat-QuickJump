// src/options/index.ts
console.log("Options page loaded");
var CONFIG_KEYS = {
  ENABLE_CHATGPT: "enable_chatgpt",
  UI_THEME: "ui_theme"
};
async function loadSettings() {
  try {
    const result = await chrome.storage.sync.get([
      CONFIG_KEYS.ENABLE_CHATGPT,
      CONFIG_KEYS.UI_THEME
    ]);
    const enableChatGPT = result[CONFIG_KEYS.ENABLE_CHATGPT] !== false;
    const uiTheme = result[CONFIG_KEYS.UI_THEME] || "auto";
    const checkbox = document.getElementById("enable-chatgpt");
    if (checkbox) {
      checkbox.checked = enableChatGPT;
    }
    const themeSelect = document.getElementById("ui-theme");
    if (themeSelect) {
      themeSelect.value = uiTheme;
    }
    console.log("\u8BBE\u7F6E\u5DF2\u52A0\u8F7D:", { enableChatGPT, uiTheme });
  } catch (error) {
    console.error("\u52A0\u8F7D\u8BBE\u7F6E\u5931\u8D25:", error);
  }
}
async function saveSetting(key, value) {
  try {
    await chrome.storage.sync.set({ [key]: value });
    showSaveStatus();
    console.log("\u8BBE\u7F6E\u5DF2\u4FDD\u5B58:", { [key]: value });
  } catch (error) {
    console.error("\u4FDD\u5B58\u8BBE\u7F6E\u5931\u8D25:", error);
  }
}
function showSaveStatus() {
  const status = document.getElementById("save-status");
  if (status) {
    status.classList.add("success");
    status.style.display = "block";
    setTimeout(() => {
      status.style.display = "none";
    }, 2e3);
  }
}
document.addEventListener("DOMContentLoaded", () => {
  loadSettings();
  const chatgptCheckbox = document.getElementById("enable-chatgpt");
  if (chatgptCheckbox) {
    chatgptCheckbox.addEventListener("change", (e) => {
      const target = e.target;
      saveSetting(CONFIG_KEYS.ENABLE_CHATGPT, target.checked);
    });
  }
  const themeSelect = document.getElementById("ui-theme");
  if (themeSelect) {
    themeSelect.addEventListener("change", (e) => {
      const target = e.target;
      saveSetting(CONFIG_KEYS.UI_THEME, target.value);
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              type: "LLM_NAV_THEME_CHANGED",
              theme: target.value
            }).catch(() => {
            });
          }
        });
      });
    });
  }
});
